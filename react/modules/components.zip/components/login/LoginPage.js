import React from 'react';
import { Component } from 'react';
import { Card, CardTitle } from 'material-ui/Card';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import { setAutherization } from '../helpers/Auth';
// https://embed.plnkr.co/plunk/OY91qM
// https://github.com/cornflourblue/react-redux-registration-login-example/blob/master/src/HomePage/HomePage.jsx
// http://www.lorejs.org/quickstart/authentication/step-5/
// https://github.com/bonham000/react-quiz-app/tree/master/src
// https://medium.com/@rajaraodv/step-by-step-guide-to-building-react-redux-apps-using-mocks-48ca0f47f9a
// https://www.codementor.io/mz026/getting-started-with-react-redux-an-intro-8r6kurcxf

import LoginForm from './LoginForm';

import { connect } from 'react-redux';
import { addFlashMessage } from '../actions/addFlashMessage';
import { loginUserRequest } from '../../services/SignupService';
import { addUser } from '../actions/UserActions';
import { setAuthorization } from '../helpers/Auth';


class LoginPage extends Component {

    render() {
        const check = localStorage.getItem('token');
        const users = this.props.users;
        const { addFlashMessage, loginUserRequest, addUser, setAutherization} = this.props;
        if(!!check){
            this.context.router.push('/my-quiz')
        }
        return(
                <LoginForm
                   addFlashMessage={addFlashMessage}
                   loginUserRequest={loginUserRequest}
                   users = {users}
                   addUser = { addUser}
                   setAutherization = { setAutherization }
                    />
        );
    }
}

LoginPage.contextTypes = {
    router: React.PropTypes.object.isRequired
}

LoginPage.propTypes = {
    loginUserRequest:React.PropTypes.func.isRequired,
    addFlashMessage: React.PropTypes.func.isRequired,
    addUser:React.PropTypes.func.isRequired
  }


function mapStateToProps(state) {
    return {
        user: state.user
    }
}

export default connect(mapStateToProps, {addFlashMessage, loginUserRequest, addUser, setAutherization})(LoginPage);
