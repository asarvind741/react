import React from 'react';

class Footer extends React.Component {
    render(){
        return(
            <div>
                @copy right reserved: 2018
            </div>
        )
    }
}

export default Footer;
