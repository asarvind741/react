var QuizQuestions = [
    {
        question: "Javascript is case-sensitive or case-insensitive ? ",
        answers: ['Yes, it is case-sensitive', 'No, it is not case-sensitive'],
        correctAnswer: 'Yes, it is case-sensitive'
    },
    {
        question: "Javascript is object-based or object-oriented ? ",
        answers: ['It is object-based', 'It is object-oriented'],
        correctAnswer: 'It is object-based'
    },
    {
        question: "Javascript is synchronous or Asynchronous ? ",
        answers: ['Synchronous', 'Asynchronous'],
        correctAnswer: 'Asynchronous'
    },
    {
        question: "Does Javascript support inheritance? ",
        answers: ['Yes', 'No'],
        correctAnswer: 'Yes'
    },
    {
        question: "Javascript is a framework? ",
        answers: ['Yes', 'No'],
        correctAnswer: 'No'
    },
    {
        question: "Javascript is single thread or multi-thread application? ",
        answers: ['Single Thread', 'Multi Thread'],
        correctAnswer: 'Single Thread'
    },
  ];
  
  export default QuizQuestions;