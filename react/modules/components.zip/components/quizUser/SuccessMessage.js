import React from 'react';

class SuccessMessge extends React.Component {


 render() {
   return (
     <div>Quiz successfully submitted</div>
   )
 }
}

export default SuccessMessge;








