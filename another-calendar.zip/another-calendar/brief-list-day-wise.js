export default [
    {
      date: '08/08/2018',
      title: 'All Day Event very long title',
      allDay: true,
      total: 50,
      briefs: [
        {
            id: 1,
            title: 'Long Event',
            time: 'test'
          },
          {
            id: 1,
            title: 'Long Event',
            time: 'test'
          },
          {
            id: 1,
            title: 'Long Event',
            time: 'test'
          },
          {
            id: 1,
            title: 'Long Event',
            time: 'test'
          }
      ]
    },
    {
        date: '08/09/2018',
        title: 'All Day Event very long title',
        allDay: true,
        total: 50,
        briefs: [
          {
              id: 1,
              title: 'Long Event',
              time: 'test'
            },
            {
              id: 1,
              title: 'Long Event',
              time: 'test'
            },
            {
              id: 1,
              title: 'Long Event',
              time: 'test'
            },
            {
              id: 1,
              title: 'Long Event',
              time: 'test'
            }
        ]
      }
  ]