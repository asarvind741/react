export default [
    {
      id: 0,
      title: 'All Day Event very long title',
      allDay: true,
      total: 50,
      date: '08/08/2018'
    },
    {
      id: 1,
      title: 'Long Event',
      total: 30,
      date: '08/08/2018'
    },
  
    {
      id: 2,
      title: 'DTS STARTS',
      total: 40,
      date: '08/08/2018'
    },
  
    {
      id: 3,
      title: 'DTS ENDS',
      total: 10,
      date: '08/08/2018'
    },
  
    {
      id: 4,
      title: 'Some Event',
      total: 330,
      date: '08/08/2018'
    },
    {
      id: 5,
      title: 'Conference',
      total: 5440,
      date: '08/08/2018',
      desc: 'Big conference for important people',
    },
    {
      id: 6,
      title: 'Meeting',
      total: 560,
      date: '08/08/2018',
      desc: 'Pre-meeting meeting, to prepare for the meeting',
    },
    {
      id: 7,
      title: 'Lunch',
      total: 5770,
      date: '09/08/2018',
      desc: 'Power lunch',
    },
    {
      id: 8,
      title: 'Meeting',
      total: 5340,
      date: '09/08/2018',
    },
    {
      id: 9,
      title: 'Happy Hour',
      total: 5450,
      date: '09/08/2018',
      desc: 'Most important meal of the day',
    }
  ]